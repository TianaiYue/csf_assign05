list team members, document who did what, discuss
anything interesting about your implementation.

Team members: Cassie Zhang xzhan304, Tianai Yue tyue4

Milestone 1
Both Cassie and Tianai did relatively equal amounts of work and effort.
Tianai implemented message, table, value_stack, and debug for all the functions.
Cassie implemented message_serialization, get_value, set_value, incr_value, and debug cases for all the functions.

